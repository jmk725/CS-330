#version 330 core

struct Material 
{
    vec3 ambientColor;
    float ambientStrength;
    vec3 diffuseColor;
    vec3 specularColor;
    float shininess;
};

struct LightSource 
{
    vec3 position;
    vec3 ambientColor;
    vec3 diffuseColor;
    vec3 specularColor;
    float focalStrength;
    float specularIntensity;
};

#define TOTAL_LIGHTS 4

in vec3 fragmentPosition;
in vec3 fragmentVertexNormal;
in vec2 fragmentTextureCoordinate;

out vec4 outFragmentColor;

uniform bool bUseTexture = false;
uniform bool bUseLighting = false;
uniform vec4 objectColor = vec4(1.0f);
uniform sampler2D objectTexture;

uniform vec3 viewPosition;
uniform vec2 UVscale = vec2(1.0f, 1.0f);

uniform LightSource lightSources[TOTAL_LIGHTS];
uniform Material material;

// ----------------------------------------------
// Corrected Phong Lighting Calculation
// ----------------------------------------------
vec3 CalcLightSource(LightSource light, vec3 normal, vec3 fragPos, vec3 viewDir)
{
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;

    // *** AMBIENT ***
    ambient = light.ambientColor * material.ambientColor * material.ambientStrength;

    // *** DIFFUSE ***
    vec3 lightDir = normalize(light.position - fragPos);
    float diffImpact = max(dot(normal, lightDir), 0.0);
    diffuse = light.diffuseColor * diffImpact * material.diffuseColor;

    // *** SPECULAR ***
    vec3 reflectDir = reflect(-lightDir, normal);
    float specComponent = pow(max(dot(viewDir, reflectDir), 0.0), light.focalStrength);

    specular = light.specularColor * light.specularIntensity * specComponent;

    return (ambient + diffuse + specular);
}


void main()
{
    vec3 normal = normalize(fragmentVertexNormal);

    if (bUseLighting)
    {
        vec3 viewDir = normalize(viewPosition - fragmentPosition);
        vec3 phongColor = vec3(0.0);

        // Accumulate all lights
        for (int i = 0; i < TOTAL_LIGHTS; i++)
        {
            phongColor += CalcLightSource(lightSources[i], normal, fragmentPosition, viewDir);
        }

        if (bUseTexture)
        {
            vec3 texColor = texture(objectTexture, fragmentTextureCoordinate * UVscale).rgb;
            phongColor *= texColor;
            outFragmentColor = vec4(phongColor, 1.0f);
        }
        else
        {
            phongColor *= objectColor.rgb;
            outFragmentColor = vec4(phongColor, objectColor.a);
        }
    }
    else
    {
        // No lighting � texture or flat color only
        if (bUseTexture)
            outFragmentColor = texture(objectTexture, fragmentTextureCoordinate * UVscale);
        else
            outFragmentColor = objectColor;
    }
}