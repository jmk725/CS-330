﻿///////////////////////////////////////////////////////////////////////////////
// main.cpp
// Entry point for the 3D scene application
//
// Handles initialization, shader loading, scene preparation, and render loop
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>

#include <GL/glew.h>
#include "GLFW/glfw3.h"

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

// Namespace for declaring global variables
namespace
{
    const char* const WINDOW_TITLE = "7-1 FinalProject and Milestones";

    GLFWwindow* g_Window = nullptr;

    ShaderManager* g_ShaderManager = nullptr;
    SceneManager* g_SceneManager = nullptr;
    ViewManager* g_ViewManager = nullptr;
}

// Function declarations
bool InitializeGLFW();
bool InitializeGLEW();

int main(int argc, char* argv[])
{
    // Initialize the GLFW library
    if (!InitializeGLFW())
        return EXIT_FAILURE;

    // Create shader manager
    g_ShaderManager = new ShaderManager();

    // Create view manager
    g_ViewManager = new ViewManager(g_ShaderManager);

    // Create the main window
    g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);
    if (!g_Window)
        return EXIT_FAILURE;

    // Initialize GLEW
    if (!InitializeGLEW())
        return EXIT_FAILURE;

    // Load shaders
    g_ShaderManager->LoadShaders(
        "C:/Users/jmk72/Desktop/CS330Content/Projects/7-1_FinalProjectMilestones/Utilities/shaders/vertexShader.glsl",
        "C:/Users/jmk72/Desktop/CS330Content/Projects/7-1_FinalProjectMilestones/Utilities/shaders/fragmentShader.glsl"
    );
    g_ShaderManager->use();

    // Create scene manager and prepare the scene
    g_SceneManager = new SceneManager(g_ShaderManager);
    g_SceneManager->PrepareScene();

    // IMPORTANT: Connect ViewManager → SceneManager for camera → lighting updates
    g_ViewManager->SetSceneManager(g_SceneManager);

    // Render loop
    while (!glfwWindowShouldClose(g_Window))
    {
        glEnable(GL_DEPTH_TEST);

        // Clear color and depth buffers
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Update camera and projection
        g_ViewManager->PrepareSceneView();

        // Render the scene
        g_SceneManager->RenderScene();

        // Swap front and back buffers
        glfwSwapBuffers(g_Window);

        // Process new events
        glfwPollEvents();
    }

    // Cleanup
    if (g_SceneManager) { delete g_SceneManager; g_SceneManager = NULL; }
    if (g_ViewManager) { delete g_ViewManager; g_ViewManager = NULL; }
    if (g_ShaderManager) { delete g_ShaderManager; g_ShaderManager = NULL; }

    exit(EXIT_SUCCESS);
}

/***********************************************************
 *  InitializeGLFW()
 ***********************************************************/
bool InitializeGLFW()
{
    glfwInit();

#ifdef __APPLE__
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif

    return true;
}

/***********************************************************
 *  InitializeGLEW()
 ***********************************************************/
bool InitializeGLEW()
{
    GLenum GLEWInitResult = glewInit();

    if (GLEWInitResult != GLEW_OK)
    {
        std::cerr << glewGetErrorString(GLEWInitResult) << std::endl;
        return false;
    }

    std::cout << "INFO: OpenGL Successfully Initialized\n";
    std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n\n";

    return true;
}