///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ============
// Manage the loading, transformation, lighting, and rendering of 3D objects
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Updated for Milestone Five with lighting support
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "shapemeshes.h"

#include <glm/glm.hpp>
#include <string>
#include <GL/glew.h>

class SceneManager
{
public:

    // Constructor / Destructor
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    // Prepare the scene (load meshes + textures)
    void PrepareScene();

    // Render the scene (draw objects)
    void RenderScene();

    // Apply lighting uniforms to shaders
    void ApplyLighting();

    // Camera position must be public so ViewManager can update it
    glm::vec3 m_cameraPos;

private:

    // Mesh objects
    ShapeMeshes* m_basicMeshes;

    // Pointer to shader manager
    ShaderManager* m_pShaderManager;

    // Texture storage
    struct TextureInfo
    {
        GLuint ID;
        std::string tag;
    };

    TextureInfo m_textureIDs[16];
    int m_loadedTextures;

    // Internal helper functions
    bool CreateGLTexture(const char* filename, std::string tag);
    void BindGLTextures();
    int FindTextureSlot(std::string tag);

    void SetTransformations(
        glm::vec3 scaleXYZ,
        float rotX, float rotY, float rotZ,
        glm::vec3 positionXYZ);

    void SetShaderColor(float r, float g, float b, float a);
    void SetShaderTexture(std::string tag);
};
