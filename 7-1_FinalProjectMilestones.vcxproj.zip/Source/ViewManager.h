///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Updated to support lighting (camera position forwarding)
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// Forward declaration to avoid circular include
class SceneManager;

// GLFW library
#include "GLFW/glfw3.h" 

class ViewManager
{
public:
    ViewManager(ShaderManager* pShaderManager);
    ~ViewManager();

    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // Prepare the view and projection matrices each frame
    void PrepareSceneView();

    // Mouse movement callback
    static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

    // Connect SceneManager so we can forward camera position
    void SetSceneManager(SceneManager* pScene);

private:
    ShaderManager* m_pShaderManager;
    GLFWwindow* m_pWindow;

    // A pointer to SceneManager for lighting integration
    SceneManager* m_pSceneManager;

    // Process keyboard input
    void ProcessKeyboardEvents();
};