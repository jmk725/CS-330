﻿///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// Manage the loading and rendering of 3D scenes
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Updated for Milestone Five to include corrected lighting system
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// Shader uniform names
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

//------------------------------------------------------------
// Constructor / Destructor
//------------------------------------------------------------
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
    m_loadedTextures = 0;

    // Initialize camera position (updated by ViewManager)
    m_cameraPos = glm::vec3(0.0f);
}

SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

//------------------------------------------------------------
// CreateGLTexture – LOADS IMAGE INTO GPU
//------------------------------------------------------------
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0, height = 0, channels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);

    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);

    if (!image)
    {
        std::cout << "Could NOT load image: " << filename << std::endl;
        return false;
    }

    std::cout << "Loaded: " << filename << std::endl;

    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    if (channels == 3)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    }
    else if (channels == 4)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    }
    else
    {
        std::cout << "Unsupported texture channel count: " << channels << std::endl;
        return false;
    }

    glGenerateMipmap(GL_TEXTURE_2D);

    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0);

    m_textureIDs[m_loadedTextures].ID = textureID;
    m_textureIDs[m_loadedTextures].tag = tag;
    m_loadedTextures++;

    return true;
}

//------------------------------------------------------------
// BindGLTextures
//------------------------------------------------------------
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
        if (m_textureIDs[i].tag == tag)
            return i;

    return -1;
}

//------------------------------------------------------------
// SetTransformations
//------------------------------------------------------------
void SceneManager::SetTransformations(glm::vec3 scaleXYZ,
    float rotX, float rotY, float rotZ,
    glm::vec3 positionXYZ)
{
    glm::mat4 model =
        glm::translate(positionXYZ) *
        glm::rotate(glm::radians(rotX), glm::vec3(1, 0, 0)) *
        glm::rotate(glm::radians(rotY), glm::vec3(0, 1, 0)) *
        glm::rotate(glm::radians(rotZ), glm::vec3(0, 0, 1)) *
        glm::scale(scaleXYZ);

    m_pShaderManager->setMat4Value(g_ModelName, model);
}

//------------------------------------------------------------
// Shader Material Controls
//------------------------------------------------------------
void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    m_pShaderManager->setIntValue(g_UseTextureName, false);
    m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
}

void SceneManager::SetShaderTexture(std::string tag)
{
    m_pShaderManager->setIntValue(g_UseTextureName, true);
    int slot = FindTextureSlot(tag);
    m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
}

//------------------------------------------------------------
// ApplyLighting — corrected lighting to prevent washed out scene
//------------------------------------------------------------
void SceneManager::ApplyLighting()
{
    m_pShaderManager->setIntValue("bUseLighting", true);
    m_pShaderManager->setVec3Value("viewPosition", m_cameraPos);

    // -------------------------------
    // MATERIAL (balanced)
    // -------------------------------
    m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(0.3f));
    m_pShaderManager->setFloatValue("material.ambientStrength", 0.2f);
    m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f));
    m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
    m_pShaderManager->setFloatValue("material.shininess", 16.0f);

    // MAIN LIGHT (warm sunlight)
    m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(10, 15, 5));
    m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.10f));
    m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(1.0f, 0.95f, 0.85f));
    m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(1.0f));
    m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 16.0f);
    m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.3f);

    // FILL LIGHT (cool, dim)
    m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(-10, 5, 8));
    m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.05f));
    m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.4f, 0.45f, 0.5f));
    m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.3f));
    m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 8.0f);
    m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.2f);

    // Turn off remaining lights
    for (int i = 2; i < 4; i++)
    {
        m_pShaderManager->setVec3Value("lightSources[i].position", glm::vec3(0));
        m_pShaderManager->setVec3Value("lightSources[i].ambientColor", glm::vec3(0));
        m_pShaderManager->setVec3Value("lightSources[i].diffuseColor", glm::vec3(0));
        m_pShaderManager->setVec3Value("lightSources[i].specularColor", glm::vec3(0));
        m_pShaderManager->setFloatValue("lightSources[i].focalStrength", 1.0f);
        m_pShaderManager->setFloatValue("lightSources[i].specularIntensity", 0.0f);
    }
}

//------------------------------------------------------------
// PrepareScene – ONE-TIME SETUP
//------------------------------------------------------------
void SceneManager::PrepareScene()
{
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();
    m_basicMeshes->LoadSphereMesh();

    CreateGLTexture("ground.jpg", "ground");
    CreateGLTexture("bucket.jpg", "bucket");
    CreateGLTexture("wood.jpg", "wood");
    CreateGLTexture("apple.jpg", "apple");

    BindGLTextures();
}

//------------------------------------------------------------
// RenderScene – DRAW EVERYTHING
//------------------------------------------------------------
void SceneManager::RenderScene()
{
    ApplyLighting();

    glm::vec3 scale;
    glm::vec3 pos;

    // Ground
    scale = glm::vec3(20, 1, 20);
    pos = glm::vec3(0, -2.5f, 0);
    SetTransformations(scale, 0, 0, 0, pos);
    SetShaderTexture("ground");
    m_basicMeshes->DrawPlaneMesh();

    // Bucket
    scale = glm::vec3(3, 4, 3);
    pos = glm::vec3(-2, 0, -4);
    SetTransformations(scale, 0, 0, 0, pos);
    SetShaderTexture("bucket");
    m_basicMeshes->DrawTaperedCylinderMesh();

    // Board
    scale = glm::vec3(4, 1, 1.5);
    pos = glm::vec3(-2, 4, -4);
    SetTransformations(scale, 0, 10, 0, pos);
    SetShaderTexture("wood");
    m_basicMeshes->DrawPlaneMesh();

    // Apple
    scale = glm::vec3(0.6f);
    pos = glm::vec3(-0.5f, 4.8f, -4);
    SetTransformations(scale, 0, 0, 0, pos);
    SetShaderTexture("apple");
    m_basicMeshes->DrawSphereMesh();
}